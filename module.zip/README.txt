Guidance for this project: 

1. Read the document "Firewall Creation.docx" for context

2. Read the document "documentation.txt" carefully for context about the files

3. Re-read the document "Stateful Connection Tracking.docx" and follow the instructions to fullfil the rquirments.

Good Luck! 
