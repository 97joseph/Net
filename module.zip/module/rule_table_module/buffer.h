
typedef struct buffer {
int n;
}buffer;
