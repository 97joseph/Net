cd /home/fw/project/ex4
./user/main show_rules
#./user/main show_rules > ./output/show_rules.txt
