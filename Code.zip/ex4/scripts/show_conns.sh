cd /home/fw/project/ex4
./user/main show_conns
# ./user/main show_conns > ./output/show_conns.txt
