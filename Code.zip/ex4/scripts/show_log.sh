cd /home/fw/project/ex4
./user/main show_log
#./user/main show_log > ./output/show_log.txt
