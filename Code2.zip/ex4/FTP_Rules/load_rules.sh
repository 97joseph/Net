cd /home/fw/project/ex4
./user/main load_rules ./examples/rules.txt