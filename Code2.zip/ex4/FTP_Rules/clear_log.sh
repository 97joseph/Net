cd /home/fw/project/ex4
./user/main clear_log